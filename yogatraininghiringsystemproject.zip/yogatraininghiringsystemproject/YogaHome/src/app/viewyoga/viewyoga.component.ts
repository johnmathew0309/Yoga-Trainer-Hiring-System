import { Component } from '@angular/core';
import { UserdataService } from '../service/userdata.service';

@Component({
  selector: 'app-viewyoga',
  templateUrl: './viewyoga.component.html',
  styleUrls: ['./viewyoga.component.css']
})
export class ViewyogaComponent {

  policy:any;
  constructor(private userdata:UserdataService){

    userdata.pol().subscribe((data)=>{
      console.log("data",data);
      this.policy=data;

    });

  }
  delete1(jobId:number){
    console.log(jobId);
    this.userdata.delete(jobId).subscribe((result)=>{
      console.warn(result);


    }
    );
  }



}
