import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ViewyogaComponent } from './viewyoga/viewyoga.component';
import { UpdateyogaComponent } from './updateyoga/updateyoga.component';
import { AddyogaComponent } from './addyoga/addyoga.component';
import { AdminNavComponent } from './admin-nav/admin-nav.component';
import { UserNavComponent } from './user-nav/user-nav.component';
import { JobseekerindexComponent } from './jobseekerindex/jobseekerindex.component';
import { JobseekerNavComponent } from './jobseeker-nav/jobseeker-nav.component';
import { UserpostComponent } from './userpost/userpost.component';
import { AdminjobsviewComponent } from './adminjobsview/adminjobsview.component';
import { AdminjobseekerviewComponent } from './adminjobseekerview/adminjobseekerview.component';
import { AdminindexComponent } from './adminindex/adminindex.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { UserindexComponent } from './userindex/userindex.component';

const routes: Routes = [
  {path:'',redirectTo: '/home',pathMatch:'full'},
  {
  path:'home',
  component:LoginComponent
  // UserNavComponent
},
  {
  path:'viewyoga',
  component: ViewyogaComponent
  },
  {
    path:'user/addyoga',
    component:UpdateyogaComponent
  },
  {
      path:'jobseeker/applyjob',
     component : JobseekerindexComponent
  },
  {
    path:'addyoga',
    component: AddyogaComponent
  },
  {
    path:'applyjob',
    component:UserpostComponent
  },
  {
    path:'admin/adminjobs',
    component:AdminjobsviewComponent
  },
  {
    path:'admin/adminjobseeker',
    component:AdminjobseekerviewComponent
  },
  {
    path:'admin/adminindex',
    component:AdminindexComponent
  },
  {
    path:'user/signup',
    component:SignupComponent
  },
  {
    path:'admin/homepage',
    component:AdminindexComponent
  },
  {
    path:'admin/logout',
    component:LoginComponent
  },
  {
    path:'user/userpage',
    component:UpdateyogaComponent
  },
  {
    path:'user/userindex',
    component:UserindexComponent
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
