import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { UserjobService } from '../service/userjob.service';


 class jobDescription1 {

  personName!: string;
  jobAdress!: string;
  personExp!:Date;
  phone!: Date;
  email!: number;
  jobId!: number;
}
@Component({
  selector: 'app-adminjobseekerview',
  templateUrl: './adminjobseekerview.component.html',
  styleUrls: ['./adminjobseekerview.component.css']
})
export class AdminjobseekerviewComponent  {

  policyForm!: FormGroup;
  policy:any;
  personName: any;
  jobAdress: any;
  personExp: any;
  phone: any;
  email: any;
  jobId: any;

  // constructor(
  // private formBuilder: FormBuilder,
  // public addjobs: UserjobService
  //  ) {  addjobs.pol1().subscribe((data)=>{
  //   console.log("data",data);
  //   this.policy=data;

  // });}

// ngOnInit(): void {
//   this.policyForm = this.formBuilder.group({

//     jobDescription: ['', Validators.required],
//     jobLocation: ['', Validators.required],
//     fromDate: ['', Validators.required],
//     toDate: ['', Validators.required],
//     wagePerDay: ['', Validators.required],
//     });
// }

yoga:any;
constructor(private useryooga:UserjobService){

  this.useryooga.pol1().subscribe((data)=>{

    console.log("data",data);
    this.yoga=data;
  }
  )
}

delete1(personId:any){
  // window.location.reload();
  console.log(personId)
  this.useryooga.delete1(personId).subscribe((result)=>{

    console.warn(result);
  })
}



}
