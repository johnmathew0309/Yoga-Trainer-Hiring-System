import { Component } from '@angular/core';

@Component({
  selector: 'app-jobseeker-nav',
  templateUrl: './jobseeker-nav.component.html',
  styleUrls: ['./jobseeker-nav.component.css']
})
export class JobseekerNavComponent {

}
