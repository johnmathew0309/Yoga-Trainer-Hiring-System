import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddyogaComponent } from './addyoga/addyoga.component';
import { ViewyogaComponent } from './viewyoga/viewyoga.component';
import { UpdateyogaComponent } from './updateyoga/updateyoga.component';
import {HttpClient, HttpClientModule} from '@angular/common/http'
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { UserpostComponent } from './userpost/userpost.component';
import { UserNavComponent } from './user-nav/user-nav.component';
import { AdminNavComponent } from './admin-nav/admin-nav.component';
import { JobseekerNavComponent } from './jobseeker-nav/jobseeker-nav.component';
import { JobseekerindexComponent } from './jobseekerindex/jobseekerindex.component';
import { AdminindexComponent } from './adminindex/adminindex.component';
import { AdminjobsviewComponent } from './adminjobsview/adminjobsview.component';
import { AdminjobseekerviewComponent } from './adminjobseekerview/adminjobseekerview.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { UserindexComponent } from './userindex/userindex.component';

@NgModule({
  declarations: [
    AppComponent,
    AddyogaComponent,
    ViewyogaComponent,
    UpdateyogaComponent,
    UserpostComponent,
    UserNavComponent,
    AdminNavComponent,
    JobseekerNavComponent,
    JobseekerindexComponent,
    AdminindexComponent,
    AdminjobsviewComponent,
    AdminjobseekerviewComponent,
    LoginComponent,
    SignupComponent,
    UserindexComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,HttpClientModule,FormsModule,ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
