import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Usermodel } from '../userpost/userpost.component';
import { Observable } from 'rxjs/internal/Observable';
const URL: any = 'https://localhost:7196/api/JobSeeker/ADDPROFILE';
@Injectable({
  providedIn: 'root'
})
export class UserjobService {
  url="https://localhost:7196/api/JobSeeker/GETPROFILE"
  constructor(private http : HttpClient) { }
  pol1(){
    return this.http.get(this.url);
  }
  url1='https://localhost:7196/api/JobSeeker/DELETEPROFILE?personId='
  delete1(personId:number){
    return this.http.delete(`${this.url1}${personId}`);
  }


  Create1(data:Usermodel):Observable<any> {
    return this.http.post(URL,data,{responseType : 'text'});
}

}
