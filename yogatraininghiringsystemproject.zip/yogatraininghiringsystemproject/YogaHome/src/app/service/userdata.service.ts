import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { PolicyModel } from '../updateyoga/updateyoga.component';
import { Observable } from 'rxjs/internal/Observable';
const URL: any = 'https://localhost:7196/api/Job/ADDJOB';
@Injectable({
  providedIn: 'root'
})
export class UserdataService {
  Create1(value: any) {
    throw new Error('Method not implemented.');
  }
  url="https://localhost:7196/api/Job";
  constructor(private http : HttpClient) { }


  Create(data:PolicyModel):Observable<any> {
    return this.http.post(URL,data,{responseType : 'text'});

        }
  // url2="https://localhost:7036/api/Job/ADDJOB"
  // Create(data:any){
  //   return this.http.post(this.url2,data);
  // }


  pol(){
    return this.http.get(this.url+'/READJOB');
  }

  url1='https://localhost:7196/api/Job/DELETEJOB?jobId='
  delete(jobId:number){
     return this.http.delete(`${this.url1}=${jobId}`);


  }
  edit(jobId:number,data:any){
    return this.http.put(this.url+'/UPDATEJOB/'+`${jobId}`,data);
  }



}
