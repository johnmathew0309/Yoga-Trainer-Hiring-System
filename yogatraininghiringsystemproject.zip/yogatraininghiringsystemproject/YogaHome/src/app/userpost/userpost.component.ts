import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { UserjobService } from '../service/userjob.service';
export class Usermodel {
  personName!: string;
  jobAdress!: string;
  personExp!:string;
  phone!: string;
  email!: number;
  jobId!: number
}
@Component({
  selector: 'app-userpost',
  templateUrl: './userpost.component.html',
  styleUrls: ['./userpost.component.css']
})
export class UserpostComponent {
  policyForm!: FormGroup;
  personName: any;
  personExp: any;
  jobAdress:any;
  phone: any;
  email: any;
  jobId: any;
  constructor(
  private formBuilder: FormBuilder,
  public addpolicy: UserjobService
   ) { }
   ngOnInit() {
    this.policyForm = this.formBuilder.group({
      personName: ['', Validators.required],
      personExp: ['', Validators.required],
      jobAdress:['',Validators.required],
      phone: ['', Validators.required],
      email: ['', Validators.required],
      jobId: ['',],
      });
     }
     onSubmit(): void {
      if (this.policyForm.valid) {
      this.addpolicy.Create1(this.policyForm.value).subscribe(res => {
      console.log(res);
         });
        this.policyForm.reset();
        }
        else {
        alert('Form should not be null'); }
          }

          edit(): void {
            if (this.policyForm.valid) {
            this.addpolicy.Create1(this.policyForm.value).subscribe(res => {
            console.log(res);
               });
              this.policyForm.reset();
              }
              else {
              alert('Form should not be null'); }
                }

}
