import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RegisterService } from '../service/register.service';
import { Router, RouterEvent } from '@angular/router';

export class RegisterModel
{
  UserName! : string
  Email1! : string
  Password!: string
  MobileNumber!: string
  UserRole! : string

}

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit
{
  registerForm !: FormGroup;
  constructor(private formBuilder: FormBuilder, public registerservice: RegisterService,public router:Router){ }
  ngOnInit() : void{
    this.registerForm = this.formBuilder.group({
      Email: ['', [Validators.required, Validators.email]],

      UserName: ['', Validators.required],

      Password: ['', [Validators.required, Validators.minLength(8)]],

      MobileNumber: ['', Validators.required],

      UserRole: ['', Validators.required]
    });
  }
  onSubmit(): void {

        if (this.registerForm.valid) {

          this.registerservice.Create(this.registerForm.value).subscribe(res=>{console.log(res)});

          this.registerForm.reset();


alert("REGISTRATION SUCCESSFULLY");
this.router.navigateByUrl('user/homepage');

        } else {

          alert('Form should not be null');

        }
}
}
