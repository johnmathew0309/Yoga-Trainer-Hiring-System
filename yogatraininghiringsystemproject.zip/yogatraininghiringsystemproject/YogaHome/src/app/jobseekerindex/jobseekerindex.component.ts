import { Component } from '@angular/core';

@Component({
  selector: 'app-jobseekerindex',
  templateUrl: './jobseekerindex.component.html',
  styleUrls: ['./jobseekerindex.component.css']
})
export class JobseekerindexComponent {

}
