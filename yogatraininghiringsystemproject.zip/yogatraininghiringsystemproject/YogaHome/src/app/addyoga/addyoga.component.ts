import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { UserdataService } from '../service/userdata.service';
  export class jobDescription {

    jobDescription!: string;
    jobLocation!: string;
    fromDate!:Date;
    toDate!: Date;
    wagePerDay!: number;
  }


@Component({
  selector: 'app-addyoga',
  templateUrl: './addyoga.component.html',
  styleUrls: ['./addyoga.component.css']
})
export class AddyogaComponent implements OnInit{
    policyForm!: FormGroup;
    policy:any;
    jobDescription: any;
    jobLocation: any;
    fromDate: any;
    toDate: any;
    wagePerDay: any;
    constructor(
    private formBuilder: FormBuilder,
    public addjobs: UserdataService
     ) {  addjobs.pol().subscribe((data)=>{
      console.log("data",data);
      this.policy=data;

    });}
  ngOnInit(): void {
    this.policyForm = this.formBuilder.group({

      jobDescription: ['', Validators.required],
      jobLocation: ['', Validators.required],
      fromDate: ['', Validators.required],
      toDate: ['', Validators.required],
      wagePerDay: ['', Validators.required],
      });

  }
  onSubmit(){

    if (this.policyForm.valid) {
    this.addjobs.Create(this.policyForm.value).subscribe((res) => {
    console.log(res);
       });
       alert("Applied Successfully")
      this.policyForm.reset();
      }
      else {
      alert('Form should not be null'); }
        }
}
