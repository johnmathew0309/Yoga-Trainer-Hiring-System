import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserdataService } from '../service/userdata.service';

export class PolicyModel {

  jobDescription!: string;
  jobLocation!: string;
  fromDate!:Date;
  toDate!: Date;
  wagePerDay!: number;
}


@Component({
  selector: 'app-updateyoga',
  templateUrl: './updateyoga.component.html',
  styleUrls: ['./updateyoga.component.css']
})
export class UpdateyogaComponent implements OnInit {
  policyForm!: FormGroup;

  jobDescription: any;
  jobLocation: any;
  fromDate: any;
  toDate: any;
  wagePerDay: any;
  constructor(
  private formBuilder: FormBuilder,
  public addpolicy: UserdataService
   ) { }
   ngOnInit() {
    this.policyForm = this.formBuilder.group({

      jobDescription: ['', Validators.required],
      jobLocation: ['', Validators.required],
      fromDate: ['', Validators.required],
      toDate: ['', Validators.required],
      wagePerDay: ['', Validators.required],
      });
     }
     onSubmit(): void {
      if (this.policyForm.valid) {
      this.addpolicy.Create(this.policyForm.value).subscribe(res => {
      console.log(res);
      alert("Added Successfully")
         });
        this.policyForm.reset();
        }
        else {
        alert('Form should not be null'); }
          }

          edit(): void {
            if (this.policyForm.valid) {
            this.addpolicy.Create(this.policyForm.value).subscribe(res => {
            console.log(res);
               });
              this.policyForm.reset();
              }
              else {
              alert('Form should not be null'); }
                }





}
