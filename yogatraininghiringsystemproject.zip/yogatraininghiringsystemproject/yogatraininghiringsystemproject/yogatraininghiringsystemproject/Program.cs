using Microsoft.EntityFrameworkCore;
using yogatraininghiringsystemproject.Context;
using yogatraininghiringsystemproject.Core.Interface;
using yogatraininghiringsystemproject.Core;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using NLog.Web;
using System;
using System.Text;

var logger = NLog.Web.NLogBuilder.ConfigureNLog("Nlog.config").GetCurrentClassLogger();
logger.Debug("init main");


try
{


    string mypolicyorigin = "myalloworigins";
    var builder = WebApplication.CreateBuilder(args);

    builder.Services.AddEndpointsApiExplorer();

    builder.Services.AddControllers();


    // Add services to the container.

    builder.Services.AddControllers();
    // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
    builder.Services.AddEndpointsApiExplorer();
    builder.Services.AddSwaggerGen();
    builder.Services.AddDbContext<yogaTrainerContext>(options => options.UseSqlServer(builder.Configuration.GetConnectionString("Connection")));
    builder.Services.AddCors(
     o => o.AddPolicy(name: mypolicyorigin, bui => { bui.AllowAnyHeader(); bui.AllowAnyOrigin(); bui.AllowAnyMethod(); }));
    builder.Services.AddScoped<IUser, User>();
    builder.Services.AddScoped<IAuth, Auth>();
    builder.Services.AddScoped<IJob,Job>();
    builder.Services.AddScoped<IJobSeeker, JobSeeker>();
    builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
                       .AddJwtBearer(options =>
                       {
                           options.TokenValidationParameters = new TokenValidationParameters
                           {
                               ValidateIssuer = false,
                               ValidateAudience = false,
                               ValidateIssuerSigningKey = true,
                               ValidateLifetime = true,
                               ValidIssuer = builder.Configuration["Jwt:Issuer"],
                               ValidAudience = builder.Configuration["Jwt:Audeience"],
                               IssuerSigningKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(builder.Configuration["Jwt:Key"]))
                           };
                       });
    builder.Logging.ClearProviders();
    builder.Logging.SetMinimumLevel(Microsoft.Extensions.Logging.LogLevel.Trace);
    builder.Host.UseNLog();
    var app = builder.Build();

    // Configure the HTTP request pipeline.
    if (app.Environment.IsDevelopment())
    {
        app.UseSwagger();
        app.UseSwaggerUI();
    }

    app.UseHttpsRedirection();
    //   app.UseAuthentication();

    app.UseRouting();
    app.UseCors(mypolicyorigin);
    //Enable Authentication
    app.UseAuthentication();
    app.UseAuthorization(); //<< This needs to be between app.UseRouting(); and app.UseEndpoints();
    app.UseEndpoints(endpoints =>
    {
        endpoints.MapControllers();
    });



    app.MapControllers();
    

    app.Run();
}
catch (Exception ex)
{
    logger.Error(ex.Message);
    throw;
}
finally
{
    NLog.LogManager.Shutdown();
}
